<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/store/admin/');
define('HTTP_CATALOG', 'http://localhost/store/');
                                       	
// HTTPS
define('HTTPS_SERVER', 'http://localhost/store/admin/');
define('HTTPS_CATALOG', 'http://localhost/store/');

// DIR
define('DIR_APPLICATION', 'C:/Apache24/htdocs/store/admin/');
define('DIR_SYSTEM', 'C:/Apache24/htdocs/store/system/');
define('DIR_IMAGE', 'C:/Apache24/htdocs/store/image/');
define('DIR_LANGUAGE', 'C:/Apache24/htdocs/store/admin/language/');
define('DIR_TEMPLATE', 'C:/Apache24/htdocs/store/admin/view/template/');
define('DIR_CONFIG', 'C:/Apache24/htdocs/store/system/config/');
define('DIR_CACHE', 'C:/Apache24/htdocs/store/system/storage/cache/');
define('DIR_DOWNLOAD', 'C:/Apache24/htdocs/store/system/storage/download/');
define('DIR_LOGS', 'C:/Apache24/htdocs/store/system/storage/logs/');
define('DIR_MODIFICATION', 'C:/Apache24/htdocs/store/system/storage/modification/');
define('DIR_UPLOAD', 'C:/Apache24/htdocs/store/system/storage/upload/');
define('DIR_CATALOG', 'C:/Apache24/htdocs/store/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'b92085mx_ocar1');
define('DB_PASSWORD', '1RNK0iIYn');
define('DB_DATABASE', 'b92085mx_ocar1');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');