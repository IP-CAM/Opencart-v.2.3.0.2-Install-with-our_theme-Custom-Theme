<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yandex_money.php';

class ControllerPaymentYandexMoneyB2bSberbank extends ControllerExtensionPaymentYandexMoney
{

}

class ControllerExtensionPaymentYandexMoneyB2bSberbank extends ControllerPaymentYandexMoneyB2bSberbank
{

}