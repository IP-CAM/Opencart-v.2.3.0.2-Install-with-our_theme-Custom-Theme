<?php
// Heading
$_['heading_title']      = 'Modified files';

// Text
$_['text_modifications'] = 'Modifications';
$_['text_list']          = 'Modified files List';
$_['text_no_results']    = 'No files modified by OCMOD.';
$_['text_file']          = 'File';
$_['text_modification']  = 'Modification';
$_['text_version']       = 'Version';
$_['text_author']        = 'Author';