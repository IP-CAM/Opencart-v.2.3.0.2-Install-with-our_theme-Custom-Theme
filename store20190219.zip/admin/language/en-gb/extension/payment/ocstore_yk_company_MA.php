<?php
$_['heading_title'] = 'Яндекс.Касса (MasterPass)';
?>