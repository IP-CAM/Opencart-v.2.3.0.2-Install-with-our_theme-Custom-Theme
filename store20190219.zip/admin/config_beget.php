<?php
// HTTP
define('HTTP_SERVER', 'http://b92085mx.beget.tech/admin/');
define('HTTP_CATALOG', 'http://b92085mx.beget.tech/');

// HTTPS
define('HTTPS_SERVER', 'http://b92085mx.beget.tech/admin/');
define('HTTPS_CATALOG', 'http://b92085mx.beget.tech/');

// DIR
define('DIR_APPLICATION', '/home/b/b92085mx/b92085mx.beget.tech/public_html/admin/');
define('DIR_SYSTEM', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/');
define('DIR_IMAGE', '/home/b/b92085mx/b92085mx.beget.tech/public_html/image/');
define('DIR_LANGUAGE', '/home/b/b92085mx/b92085mx.beget.tech/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/b/b92085mx/b92085mx.beget.tech/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/config/');
define('DIR_CACHE', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/storage/download/');
define('DIR_LOGS', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/b/b92085mx/b92085mx.beget.tech/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/b/b92085mx/b92085mx.beget.tech/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'b92085mx_ocar1');
define('DB_PASSWORD', '1RNK0iIYn');
define('DB_DATABASE', 'b92085mx_ocar1');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');